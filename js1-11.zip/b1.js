// console.log('huy kieu')
// var bien1=10;
// var bien2=20;
// var bien3=bien2+bien1;

// console.log(bien1)
// console.log(bien2)
// console.log(bien3)

var x=1,y=2;
var z="hello";
var b=5;
console.log(5%3);
function chaythu(){
    b=b+1;
    console.log('hkdi'+((b%5)+1));
}

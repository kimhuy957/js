var diem =4;
if(diem==4){
    console.log('bang4');

}
else
{
    console.log('ko bang 4');
}
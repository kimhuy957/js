var hk=["html","css","js"];
console.log(hv[2]);
//c2
var hv2=[];
hn2="h";
hv2="uy";
hv2="huy";
console.log(hv2[2]);


//cach3: dung tu khoa new
var hv=new Array('huy','linh')
console.log(hv3[1]);
